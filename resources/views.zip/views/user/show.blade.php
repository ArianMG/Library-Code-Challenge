@extends('layouts.app', [])

@section('content')
    User <b>{{ $user->name }}</b>
@endsection
